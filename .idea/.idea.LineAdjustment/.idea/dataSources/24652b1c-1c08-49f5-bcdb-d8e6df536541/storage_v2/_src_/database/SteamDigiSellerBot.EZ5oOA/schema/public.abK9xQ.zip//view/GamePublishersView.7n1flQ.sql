create view "GamePublishersView"("Id", "GamePublisherId", "GameId", "Name") as
SELECT row_number()
       OVER (PARTITION BY gp."Id", (pub.value ->> 'creator_clan_account_id'::text) ORDER BY (pub.value ->> 'creator_clan_account_id'::text)) AS "Id",
       (pub.value ->> 'creator_clan_account_id'::text)::bigint                                                                               AS "GamePublisherId",
       gp."Id"                                                                                                                               AS "GameId",
       pub.value ->> 'name'::text                                                                                                            AS "Name"
FROM "Games" gp,
     LATERAL json_array_elements((gp."GameInfo" -> 'basic_info'::text) -> 'publishers'::text) pub(value)
WHERE ((pub.value ->> 'creator_clan_account_id'::text)::bigint) IS NOT NULL;

alter table "GamePublishersView"
    owner to postgres;

